"""Configure this extracted folder in place; never copies match templates."""
import sys
from pathlib import Path
import tkinter
import yaml


def configure(package, executable):
    package = Path(package).resolve()
    match = next((p for p in package.parents if p.name.lower() == 'match'), None)
    if match is None:
        raise ValueError('Extract this folder inside your Espanso match folder before running setup.')
    script = package / 'scripts/mycolor.py'
    if not script.is_file():
        raise ValueError('scripts/mycolor.py is missing. Extract the entire ZIP first.')
    file = package / 'mycolor.yml'
    data = yaml.safe_load(file.read_text(encoding='utf-8'))
    args = data['matches'][0]['vars'][1]['params']['args']
    args[0] = str(executable)
    args[1] = '%CONFIG%/match/' + script.relative_to(match).as_posix()
    temporary = file.with_suffix('.tmp')
    temporary.write_text(yaml.safe_dump(data, sort_keys=False), encoding='utf-8')
    temporary.replace(file)
    return match


if __name__ == '__main__':
    try:
        folder = configure(Path(__file__).parent, sys.executable)
        print(f'Ready. New colors will be saved in {folder / "mycolors.yml"}')
        print('Restart Espanso and type :mycolor in Notepad.')
    except Exception as error:
        print(f'Setup failed: {error}', file=sys.stderr)
        sys.exit(1)
