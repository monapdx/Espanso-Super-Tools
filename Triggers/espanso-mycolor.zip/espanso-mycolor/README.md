# Personal colors: extract inside match

Requires Espanso 2 and Python 3.10+ with tkinter. Standard Windows Python includes tkinter; the `python` command must work for setup.

1. Download the ZIP into `%APPDATA%\espanso\match`.
2. Extract it there. The ZIP contains one `espanso-mycolor` folder. Windows Extract All may create an additional outer folder; setup supports that too.
3. Inside the extracted folder, double-click `setup-windows.bat` once. It installs PyYAML, then updates the bundled `mycolor.yml` to use this Python executable and the actual extracted script location. It does not move files or create another trigger template.
4. Restart Espanso. Type `:mycolor` in Notepad. Enter a name, hex code, and choose Save to my colors or Generate YAML only.

New colors are saved in `match/mycolors.yml`, beside the extracted package folder. Save mode inserts no text; YAML-only mode inserts a complete YAML document into your active editor. When pasting into an existing matches list, copy only its list entry, not a second `matches:` header.

Before switching from an older version, remove its old :mycolor definition (including any definition pasted into base.yml). Keep your existing color data. Do not keep two extracted versions under match: Espanso will load both and show a chooser. If you have an older `my-colors.yml`, back it up and rename it to `mycolors.yml` only if the destination does not already exist. If both exist, merge them manually to avoid losing colors.

Run setup again if you move or rename the extracted folder. If pip fails, setup stops and displays the error. No Espanso command on PATH is required. If Python is unavailable, install it before setup.

Names start with a letter and may contain letters, digits, underscores and hyphens (64 characters maximum). An optional leading colon is accepted. :mycolor is reserved. Hex values accept 3, 4, 6 or 8 digits, with or without #; four/eight digits include alpha transparency.

Updating an existing simple color requires confirmation. Conflicting triggers in other YAML files beneath match are blocked. Regex triggers and imports outside match are not checked. The previous palette is backed up as mycolors.yml.bak. Comments and formatting in this managed file are not preserved. Backspace undo does not undo file saves. A crashed save may leave match/.mycolor.lock; remove it only when no save is running.

To uninstall, remove the extracted package folder. Your match/mycolors.yml remains usable independently.

The helper and extracted-path setup are tested programmatically. A live Windows Espanso test is still required.
