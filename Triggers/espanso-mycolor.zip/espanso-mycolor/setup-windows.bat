@echo off
setlocal
cd /d "%~dp0"
python -m pip install "PyYAML>=6.0,<7"
if errorlevel 1 goto failed
python "%~dp0setup.py"
if errorlevel 1 goto failed
pause
exit /b 0
:failed
echo Setup failed. Read the message above. Python with tkinter must be installed.
pause
exit /b 1
