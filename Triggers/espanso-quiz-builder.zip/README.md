# Quiz Builder for Espanso

Make a playable, shareable quiz without opening a quiz-building website.

## Install (Windows)

1. Open your Espanso folder. It is usually `%APPDATA%\espanso`. If yours is elsewhere, run `espanso path` to find it.
2. Open the `match` folder and extract the ZIP's contents directly into it.
3. Check that `quiz-builder.yml` is directly inside `match`, with the `quiz-builder` folder beside it. Do not put everything inside another outer folder.
4. Restart Espanso.

Requires Espanso 2.x and Windows PowerShell, which comes with Windows. No Python, Node, or extra apps needed. The trigger uses PowerShell's Bypass option for this one process; it does not change your computer's execution-policy settings. Organization-managed restrictions may still prevent scripts from running.

## Make a quiz

1. Type `:quiz` in a plain text area, such as Notepad.
2. Enter the quiz title, an optional description, and the correct answers, one per line.
3. Click Submit or press Ctrl+Enter.

Your quiz is saved in **Documents → Espanso Quizzes**. Espanso replaces the trigger with the saved file's full path. Open that HTML file in a browser to play, or send it to someone else.

The form has the same three inputs as the original builder. Espanso supplies its own form appearance; the HTML quiz keeps the original blue Submit button, green answer tiles, answer counter, and circular progress display. The web builder's preview/download buttons are replaced by saving the file directly.

Blank titles become “Quiz.” Blank answer lines are ignored. Repeated answers count only once, regardless of capitalization. Existing files are preserved: making the same title again adds `-2`, `-3`, and so on. An empty answer list produces a message instead of a broken quiz.

The finished quiz works offline. An internet connection only supplies the optional Oswald font; an ordinary font appears without it. There are no separate CSS or JavaScript files to send with your quiz. Correct answers are stored in its source, as in the original, so this is for casual quizzes rather than secure exams.

## Try it

Title: 90s Riot Grrrl Band Name Quiz

Description: Guess as many band names as you can. Spelling counts, but capitalization doesn't.

Answers:

```text
bikini kill
bratmobile
sleater kinney
l7
babes in toyland
le tigre
hole
```

## Files

- `quiz-builder.yml` — the trigger and its form.
- `quiz-builder/generate.ps1` — saves your HTML file.
- `quiz-builder/quiz-template.html` — the quiz's appearance and behavior.

Keep the two helper files together in `match/quiz-builder`. To change the trigger, edit `:quiz` in the YAML file. To change the quiz's styling, edit the template's CSS.

Reference: https://espanso.org/docs/matches/forms/

Validation: YAML parsed and browser quiz logic checked with simulated DOM/canvas, including duplicate guesses and script-like answer text. The Windows PowerShell/Espanso workflow could not be run in the Linux build environment; try the demo after installing.
