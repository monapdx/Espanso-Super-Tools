# Form content is read as data, never interpolated into executable commands.
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
try {
    $quizTitle = [string]$env:ESPANSO_QUIZFORM_TITLE
    if ([string]::IsNullOrWhiteSpace($quizTitle)) { $quizTitle = 'Quiz' }
    $quizDescription = [string]$env:ESPANSO_QUIZFORM_DESCRIPTION
    $answerText = [string]$env:ESPANSO_QUIZFORM_ANSWERS
    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    $answers = New-Object 'System.Collections.Generic.List[string]'
    foreach ($line in ($answerText -split '\r\n|\n|\r')) {
        $answer = $line.Trim()
        if ($answer.Length -gt 0 -and $seen.Add($answer)) { $answers.Add($answer) }
    }
    if ($answers.Count -eq 0) {
        [Console]::Write('Quiz not created: enter at least one answer, one per line. Type :quiz to try again.')
        exit 0
    }
    # -InputObject preserves array brackets even for a quiz with a single answer.
    $answerJson = ConvertTo-Json -InputObject @($answers.ToArray()) -Compress
    # Escape HTML parser delimiters, including a literal closing script tag.
    $answerJson = $answerJson.Replace('&', '\u0026').Replace('<', '\u003c').Replace('>', '\u003e').Replace([string][char]0x2028, '\u2028').Replace([string][char]0x2029, '\u2029')
    $values = @{
        TITLE = [System.Net.WebUtility]::HtmlEncode($quizTitle)
        DESCRIPTION = [System.Net.WebUtility]::HtmlEncode($quizDescription)
        ANSWERS = $answerJson
        TOTAL = [string]$answers.Count
    }
    $template = [System.IO.File]::ReadAllText((Join-Path $PSScriptRoot 'quiz-template.html'))
    # A single pass prevents text entered by the user from becoming another placeholder.
    $html = [regex]::Replace($template, '@@QUIZ_(TITLE|DESCRIPTION|ANSWERS|TOTAL)@@', [System.Text.RegularExpressions.MatchEvaluator]{ param($m) $values[$m.Groups[1].Value] })
    $documents = [Environment]::GetFolderPath('MyDocuments')
    if ([string]::IsNullOrWhiteSpace($documents)) { $documents = Join-Path $env:USERPROFILE 'Documents' }
    $folder = Join-Path $documents 'Espanso Quizzes'
    [System.IO.Directory]::CreateDirectory($folder) | Out-Null
    $slug = [regex]::Replace($quizTitle.ToLowerInvariant(), '[^a-z0-9]+', '-').Trim('-')
    if ($slug.Length -eq 0) { $slug = 'quiz' }
    if ($slug.Length -gt 70) { $slug = $slug.Substring(0, 70).TrimEnd('-') }
    # CreateNew protects existing quizzes even if two runs use the same title.
    $number = 1
    while ($true) {
        $suffix = if ($number -eq 1) { '' } else { '-' + $number }
        $path = Join-Path $folder ($slug + $suffix + '.html')
        try {
            $stream = [System.IO.File]::Open($path, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
            break
        } catch [System.IO.IOException] {
            if (-not [System.IO.File]::Exists($path)) { throw }
            $number++
        }
    }
    try {
        $bytes = (New-Object System.Text.UTF8Encoding($false)).GetBytes($html)
        $stream.Write($bytes, 0, $bytes.Length)
    } finally { $stream.Dispose() }
    [Console]::Write($path)
} catch {
    [Console]::Write('Quiz could not be created: ' + $_.Exception.Message)
}
